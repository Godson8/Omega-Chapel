"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 1105:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
;// CONCATENATED MODULE: ./components/Footer/Footer.tsx





const Footer = ()=>{
    const year = new Date().getFullYear();
    console.log(year);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-[#131825] mt-16 md:mt-[134px] text-white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container space-y-14 text-white pb-16 md:pb-28",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "space-y-8 md:space-y-0 md:space-x-24 flex justify-center flex-col md:flex-row pt-16 md:pt-28 md:justify-items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-8 max-w-xs",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "relative cursor-pointer flex items-center space-x-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "/logo.png",
                                                alt: "Logo",
                                                height: 28,
                                                width: 28
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-xl font-bold text-white",
                                                children: "Omega Chapel"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex space-x-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cursor-pointer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://www.facebook.com/Omega-Chapel-106683021365817",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-center items-center h-8 w-8 border rounded-full",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookF, {
                                                        color: "white",
                                                        size: 12
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cursor-pointer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://www.instagram.com/omega.chapel/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-center items-center h-8 w-8 border rounded-full",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaInstagram, {
                                                        color: "white",
                                                        size: 12
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cursor-pointer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://www.youtube.com/@omegachapel",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-center items-center h-8 w-8 border rounded-full",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillYoutube, {
                                                        color: "white",
                                                        size: 12
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "cursor-pointer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "https://www.facebook.com/OmegaBelieversGotTalent",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-center items-center h-8 w-8 border rounded-full",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookF, {
                                                        color: "white",
                                                        size: 12
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-sm text-white",
                                    children: "hello@omegachapel.org"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "space-y-8 text-white",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Lagos, Nigeria"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-sm",
                                                    children: "3b, Boundary road, Akowonjo, Lagos."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Ota, Nigeria"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-sm",
                                                    children: "Dickson Omotayo crescent, behind town hall opposite AUD Ota."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Ilogbo, Nigeria"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-sm",
                                                    children: "No 18, asenuga crescent, iyamala bus stop, off Ilogbo road, Ilogbo Ogun State."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Manchester, UK"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-sm",
                                                    children: "32, Ivy Street, off Moston lane, Manchester M40 9LN."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid grid-cols-1 md:grid-cols-4 gap-y-8 md:gap-y-0 md:gap-x-24",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col space-y-8",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[#eee] flex-col space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "About"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/our-mission",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Our Mission"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/our-beliefs",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Our Beliefs"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/our-leadership",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Our Leadership"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/our-schedule",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Our Schedule"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[#eee] flex-col space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Media"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/sermons",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Sermons"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/music",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Music"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col space-y-8",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[#eee] flex-col space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Locations"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/locations/nigeria",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm ",
                                                        children: "Nigeria"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/locations/united-kingdom",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "United Kingdom"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/locations/canada",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Canada"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[#eee] flex-col space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Contact"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/contact",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Contact Us"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-[#eee] flex-col space-y-3",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-md font-semibold",
                                                children: "Generations"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/youths",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Youths"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/kiddies",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Kiddies"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Men of David"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Women of honour"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Singles"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Young Couples"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "cursor-pointer text-sm",
                                                    children: "Samuel’s company"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "space-y-5",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[#eee] flex-col space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Finance"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/giving",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Giving"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-[#eee] flex-col space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    className: "text-md font-semibold",
                                                    children: "Legal"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Privacy Policy"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "cursor-pointer text-sm",
                                                        children: "Terms of Use"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-white text-sm text-center",
                    children: [
                        "All rights Reserved. \xa9 ",
                        year,
                        " Omega Chapel International Churches . All Rights Reserved"
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/NavBar/NavBar.tsx




const NavBar = ()=>{
    const { 0: toggle , 1: setToggle  } = (0,external_react_.useState)(false);
    const { 0: showAbout , 1: setShowAbout  } = (0,external_react_.useState)(false);
    const { 0: showMedia , 1: setShowMedia  } = (0,external_react_.useState)(false);
    const { 0: showGenerations , 1: setShowGenerations  } = (0,external_react_.useState)(false);
    const { 0: navBar , 1: setNavBar  } = (0,external_react_.useState)(false);
    const showNavBar = ()=>{
        if (window.scrollY >= 67) {
            setNavBar(true);
        } else {
            setNavBar(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", showNavBar);
    }, []);
    const handleToggle = ()=>{
        setToggle(!toggle);
    };
    const closeMobileMenu = ()=>{
        setToggle(!toggle);
    };
    const openAbout = ()=>{
        setShowAbout(!showAbout);
    };
    const openMedia = ()=>{
        setShowMedia(!showMedia);
    };
    const openGenerations = ()=>{
        setShowGenerations(!showGenerations);
    };
    const navLinkStyles = ({ isActive  })=>{
        return {
            color: isActive && "#649AE9"
        };
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: `${navBar && "shadow-nav"} bg-white sticky top-0  z-[99999] w-full`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container z-30 bg-white",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-white w-full flex justify-between items-center h-[67px]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-8 h-8 relative cursor-pointer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/logo.png",
                                alt: "Logo",
                                layout: "fill"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center items-center w-8 h-8 cursor-pointer md:hidden",
                        onClick: handleToggle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `w-7 h-1 before:bg-primary after:bg-primary rounded-full before:content-[''] after:content-[''] before:absolute after:absolute before:rounded-full after:rounded-full before:w-7  after:w-7 before:h-1 after:h-1 transition after:transition before: ease-in-out after:ease-in-out before:duration-500 after:duration-500
                    ${!toggle ? " bg-primary before:-translate-y-2.5 after:translate-y-2.5" : " bg-transparent  before:rotate-45 after:-rotate-45"}`
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: ` mobile:absolute mobile:w-full  mobile:bg-white mobile:right-0 mobile:transition-all mobile:ease-in-out mobile:-z-10 mobile:shadow-nav
                  ${toggle ? " mobile:top-16 mobile:duration-700 mobile:overflow-y-scroll max-h-screen mobile:border-t mobile:border-opacity-30  mobile:border-solid" : " mobile:-top-[750px]  mobile:duration-500 "}`,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: " flex space-x-8 mobile:hidden text-sm text-primary ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "w-full relative",
                                        onMouseEnter: openAbout,
                                        onMouseLeave: ()=>setShowAbout(false),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "cursor-pointer hover:text-secondary transition-colors",
                                                children: "About"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: `${!showAbout && "hidden"}  w-96 absolute bg-white shadow-nav p-4 -translate-x-1/2 rounded-xl divide-y-[0.5px] divide-primary divide-opacity-20 divide-dashed`,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                        className: "text-xs pb-2 ",
                                                        children: "Who are we?"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${!showAbout && "hidden"}  grid grid-cols-2 gap-y-1 gap-x-2 `,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/our-mission",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Our Mission"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "What we are called to do and how we do it."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/our-leadership",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Our Leadership"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Get to know our team of leaders"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/our-beliefs",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Our Beliefs"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "What we know, believe and hold to be true"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/our-schedule",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Our Schedule"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Get to follow our events and programmes"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "w-full h-full relative",
                                        onMouseEnter: openMedia,
                                        onMouseLeave: ()=>setShowMedia(false),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "cursor-pointer hover:text-secondary transition-colors",
                                                children: "Media"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: `${!showMedia && "hidden"}  w-96 absolute bg-white shadow-nav p-4 -translate-x-1/2 rounded-xl divide-y-[0.5px] divide-primary divide-opacity-20 divide-dashed`,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                        className: "text-xs pb-2",
                                                        children: "The Omega Media"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${!showMedia && "hidden"}  grid grid-cols-2 gap-y-1 gap-x-2 `,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/sermons",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Sermons"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "How we preach and teach the Uncompromised word of God"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/music",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Music"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Anointed Tunes in worship and praise of God"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "w-full h-full relative",
                                        onMouseEnter: openGenerations,
                                        onMouseLeave: ()=>setShowGenerations(false),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "cursor-pointer hover:text-secondary transition-colors",
                                                children: "Generations"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: `${!showGenerations && "hidden"}  w-96 absolute bg-white shadow-nav p-4 -translate-x-1/2 rounded-xl divide-y-[0.5px] divide-primary divide-opacity-20 divide-dashed`,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                        className: "text-xs pb-2",
                                                        children: "Omega Generations"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: `${!showGenerations && "hidden"}  grid grid-cols-2 gap-x-2 `,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/youths",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Youths"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Eagle’s nest: the fellowship of our youngsters."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "/kiddies",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Kiddies"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Our children are Mighty seeds: God’s heritage."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Men of David"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Building pillars that hold the house."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Women of honour"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Support for the unique needs of a woman."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Singles"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Unmarried young adults in search of spouse and success."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Young couples"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Building a strong marriage and home for the Lord."
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: "hover:bg-tertiary p-2 cursor-pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                            className: "text-sm font-bold",
                                                                            children: "Samuel’s company"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                            className: "text-xs",
                                                                            children: "Special fellowship of minister’s kids."
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "hover:text-secondary transition-all",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/locations",
                                            children: "Locations"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "hover:text-secondary transition-all",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/contact",
                                            children: "Contact"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "text-secondary font-bold hover:text-secondary transition-colors",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/giving",
                                            children: "Giving"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `container divide-y-[0.5px] divide-primary divide-opacity-20 divide-dashed pb-8 md:hidden h-full ${toggle && "mb-10"}`,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "py-4 space-y-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold text-sm",
                                                children: "ABOUT"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-2 gap-4 gap-y-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/our-mission",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Our Mission"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/our-beliefs",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Our Beliefs"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/our-leadership",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Our Leadership"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/our-schedule",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Our Schedule"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "py-4 space-y-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold text-sm",
                                                children: "MEDIA"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-2 gap-4 gap-y-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/sermons",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Sermons"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/music",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Music"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "py-4 space-y-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold text-sm",
                                                children: "GENERATIONS"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "grid grid-cols-2 gap-4 gap-y-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/youths",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Youths"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/kiddies",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Kiddies"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Men of David"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Women of honour"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Singles"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Young Couples"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            onClick: handleToggle,
                                                            className: "text-sm",
                                                            children: "Samuel’s company"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "py-4 space-y-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold text-sm",
                                                children: "LOCATIONS"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "grid grid-cols-2 gap-4 gap-y-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/locations",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        onClick: handleToggle,
                                                        className: "text-sm",
                                                        children: "Locations"
                                                    })
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "py-4 space-y-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold text-sm",
                                                children: "CONTACT"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "grid grid-cols-2 gap-4 gap-y-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/contact",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        onClick: handleToggle,
                                                        className: "text-sm",
                                                        children: "Contact"
                                                    })
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "py-4 space-y-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold text-sm",
                                                children: "GIVING"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "grid grid-cols-2 gap-4 gap-y-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/giving",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        onClick: handleToggle,
                                                        className: "text-sm",
                                                        children: "Giving"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const NavBar_NavBar = (NavBar);

;// CONCATENATED MODULE: ./components/Layout/Layout.tsx




const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Omega Chapel - Welcome Home -"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Omega Chapel - Welcome Home -"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/logo.png"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NavBar_NavBar, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
        ]
    });
};
/* harmony default export */ const Layout_Layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.tsx



// import "swiper/css/bundle";


function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Layout_Layout, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,61], () => (__webpack_exec__(1105)));
module.exports = __webpack_exports__;

})();