"use strict";
exports.id = 231;
exports.ids = [231];
exports.modules = {

/***/ 9231:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1957);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1492);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var dateformat__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(400);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__, firebase_firestore__WEBPACK_IMPORTED_MODULE_3__, dateformat__WEBPACK_IMPORTED_MODULE_5__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_1__, _firebaseConfig__WEBPACK_IMPORTED_MODULE_2__, firebase_firestore__WEBPACK_IMPORTED_MODULE_3__, dateformat__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Newsletter = ()=>{
    const databaseRef = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.collection)(_firebaseConfig__WEBPACK_IMPORTED_MODULE_2__/* .database */ .F, "Newsletter");
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { 0: errorOpen , 1: setErrorOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { register , getValues , handleSubmit , formState , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useForm)();
    const { isSubmitting  } = formState;
    const addData = ()=>{
        (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.addDoc)(databaseRef, {});
    };
    const handleClose = (event, reason)=>{
        if (reason === "clickaway") {
            return;
        }
        setOpen(false);
    };
    const onSubmit = (data)=>{
        console.log(data);
        reset();
        (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_3__.addDoc)(databaseRef, {
            Email: data.email,
            date: (0,dateformat__WEBPACK_IMPORTED_MODULE_5__["default"])(new Date())
        }).then(()=>{
            setOpen(true);
        }).catch(()=>{
            setErrorOpen(true);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container mt-16 md:mt-[100px] space-y-20",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-[32px] font-bold text-center",
                        children: "Subscribe to our Newsletter"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-center",
                        children: "Get notified of our upcoming programs"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    onSubmit: handleSubmit(onSubmit),
                    className: "w-full md:space-x-[24px] flex flex-col items-center space-y-4 md:space-y-0 md:flex-row justify-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            ...register("email", {
                                required: true
                            }),
                            placeholder: "Email address",
                            className: "text-sm px-[18px] py-3 bg-[#F2F7FF] text-primary w-full max-w-[377px] focus:border focus:outline-none focus:border-primary rounded-md"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "bg-secondary text-white text-sm px-[18px] py-3 font-bold w-fit rounded-xl hover:scale-105 transition-transform duration-200 ease-in-out flex items-center space-x-1 disabled:bg-tertiary disabled:text-secondary",
                            disabled: isSubmitting,
                            children: [
                                isSubmitting && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_6__.Oval, {
                                    height: 15,
                                    width: 15,
                                    color: "#4fa94d",
                                    wrapperStyle: {},
                                    wrapperClass: "",
                                    visible: true,
                                    ariaLabel: "oval-loading",
                                    secondaryColor: "#4fa94d",
                                    strokeWidth: 10,
                                    strokeWidthSecondary: 8
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: isSubmitting ? "Submitting" : "Submit"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Snackbar, {
                open: open,
                autoHideDuration: 8000,
                onClose: handleClose,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Alert, {
                    onClose: handleClose,
                    severity: "success",
                    sx: {
                        width: "100%"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.AlertTitle, {
                            children: "Success"
                        }),
                        "Thank you for signing up to our Newsletter. We will be in touch with you as soon as possible \uD83D\uDE0A"
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Snackbar, {
                open: errorOpen,
                autoHideDuration: 8000,
                onClose: handleClose,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Alert, {
                    onClose: handleClose,
                    severity: "error",
                    sx: {
                        width: "100%"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.AlertTitle, {
                            children: "Error"
                        }),
                        "Sorry, please try again."
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Newsletter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;